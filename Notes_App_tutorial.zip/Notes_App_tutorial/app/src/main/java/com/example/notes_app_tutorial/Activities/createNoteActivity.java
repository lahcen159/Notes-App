package com.example.notes_app_tutorial.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.notes_app_tutorial.Entities.Note;
import com.example.notes_app_tutorial.R;
import com.example.notes_app_tutorial.database.NotesDatabase;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class createNoteActivity extends AppCompatActivity {
    private EditText inputTitle, inputSubtitle, inputNote;

    private TextView textDateTime;
    private ImageView noteImage;
    private TextView textUrl;
    private LinearLayout layout_url;

    private String selectedImagePath;
    private String noteColorSelected;
    private View subtitleIndicatorView;

    private AlertDialog alertDialogAddUrl;
    private AlertDialog alertDialogDeleteNote;

    private Note alreadyAvailableNote;

    private static final int REQUEST_CODE_STORAGE_PERMISSION = 1;
    private static final int REQUEST_CODE_SELECT_IMAGE = 2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note);
        initViews(); // initialize the title, subtitle and the note Views
        backImage(); // getting back cuz of the action on the back Button
        saveImage(); // registration of the note

        if(getIntent().getBooleanExtra("isViewOrUpdate", false)){
        alreadyAvailableNote = (Note) getIntent().getSerializableExtra("note");
        setViewOrUpdateNote();
        }

        findViewById(R.id.removeUrlBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textUrl.setText(null);
                layout_url.setVisibility(View.GONE);

            }
        });// this to remove the Url
        findViewById(R.id.removeImageBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteImage.setImageBitmap(null);
                noteImage.setVisibility(View.GONE);
                findViewById(R.id.removeImageBtn).setVisibility(View.GONE);
                selectedImagePath = "";
            }
        });// this to remove the Image


        if(getIntent().getBooleanExtra("isFromQuickActions", false)){

            String type = getIntent().getStringExtra("quickActionType");
            if(type!=null){
                if(type.equals("image")){
                    selectedImagePath = getIntent().getStringExtra("imagePath");
                    noteImage.setImageBitmap(BitmapFactory.decodeFile(selectedImagePath));
                    noteImage.setVisibility(View.VISIBLE);
                    findViewById(R.id.removeImageBtn).setVisibility(View.VISIBLE);
                }else if(type.equals("url")){
                    textUrl.setText(getIntent().getStringExtra("urlPath"));
                    textUrl.setVisibility(View.VISIBLE);
                    layout_url.setVisibility(View.VISIBLE);
                }
            }
        }
        initMiscellaneous();
    }

    private void setViewOrUpdateNote() {
inputTitle.setText(alreadyAvailableNote.getTitle());
inputSubtitle.setText(alreadyAvailableNote.getSubtitle());
inputNote.setText(alreadyAvailableNote.getNoteText());
textDateTime.setText(alreadyAvailableNote.getDateTime());

if(alreadyAvailableNote.getImagePath() != null && !alreadyAvailableNote.getImagePath().trim().isEmpty()){
    noteImage.setImageBitmap(BitmapFactory.decodeFile(alreadyAvailableNote.getImagePath()));;
    noteImage.setVisibility(View.VISIBLE);
    findViewById(R.id.removeImageBtn).setVisibility(View.VISIBLE);
    selectedImagePath = alreadyAvailableNote.getImagePath();
    }
    if(alreadyAvailableNote.getWebLink() != null && !alreadyAvailableNote.getWebLink().trim().isEmpty()){
        textUrl.setText(alreadyAvailableNote.getWebLink());
        layout_url.setVisibility(View.VISIBLE);
    }
    }


    private void initMiscellaneous() {
        final LinearLayout miscellaneouslayout = findViewById(R.id.miscellaneous_layout);
        final BottomSheetBehavior<LinearLayout> bottomSheetBehavior = BottomSheetBehavior.from(miscellaneouslayout);
        miscellaneouslayout.findViewById(R.id.miscellaneous_title).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bottomSheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                }
            }
        });
        final ImageView imageView1 = findViewById(R.id.imageColor1);
        final ImageView imageView2 = findViewById(R.id.imageColor2);
        final ImageView imageView3 = findViewById(R.id.imageColor3);
        final ImageView imageView4 = findViewById(R.id.imageColor4);
        final ImageView imageView5 = findViewById(R.id.imageColor5);

        miscellaneouslayout.findViewById(R.id.viewColor1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteColorSelected = "#333333";
                imageView1.setImageResource(R.drawable.ic_baseline_done_24);
                imageView2.setImageResource(0);
                imageView3.setImageResource(0);
                imageView4.setImageResource(0);
                imageView5.setImageResource(0);
                setSubtitleIndicatorColor();
            }
        });
        miscellaneouslayout.findViewById(R.id.viewColor2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteColorSelected = "#FDBE3B";
                imageView2.setImageResource(R.drawable.ic_baseline_done_24);
                imageView1.setImageResource(0);
                imageView3.setImageResource(0);
                imageView4.setImageResource(0);
                imageView5.setImageResource(0);
                setSubtitleIndicatorColor();
            }
        });
        miscellaneouslayout.findViewById(R.id.viewColor3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteColorSelected = "#FF4842";
                imageView3.setImageResource(R.drawable.ic_baseline_done_24);
                imageView2.setImageResource(0);
                imageView1.setImageResource(0);
                imageView4.setImageResource(0);
                imageView5.setImageResource(0);
                setSubtitleIndicatorColor();
            }
        });
        miscellaneouslayout.findViewById(R.id.viewColor4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteColorSelected = "#3A52Fc";
                imageView4.setImageResource(R.drawable.ic_baseline_done_24);
                imageView2.setImageResource(0);
                imageView1.setImageResource(0);
                imageView3.setImageResource(0);
                imageView5.setImageResource(0);
                setSubtitleIndicatorColor();
            }
        });
        miscellaneouslayout.findViewById(R.id.viewColor5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                noteColorSelected = "#000000";
                imageView5.setImageResource(R.drawable.ic_baseline_done_24);
                imageView2.setImageResource(0);
                imageView1.setImageResource(0);
                imageView3.setImageResource(0);
                imageView4.setImageResource(0);
                setSubtitleIndicatorColor();
            }
        });

        miscellaneouslayout.findViewById(R.id.addImage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                if (ContextCompat.checkSelfPermission(
                        getApplicationContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) { //we check if we get the permission

                    ActivityCompat.requestPermissions(createNoteActivity.this, // if not, we gonna ask to get it and we get the result in onRequestPermissionResult

                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            REQUEST_CODE_STORAGE_PERMISSION);
                } else {
                    Log.d("Access", " : we have access and we lunch the intent to open the resources");//if yes then we get access and lunch to get the Photo
                    selectImage();
                }
            }
        });
        miscellaneouslayout.findViewById(R.id.layoutAddUrl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                showAddUrlDialog();
            }
        });

        if(alreadyAvailableNote != null && alreadyAvailableNote.getColor()!=null && !alreadyAvailableNote.getColor().trim().isEmpty()){
            switch(alreadyAvailableNote.getColor()){
                case "#333333":  miscellaneouslayout.findViewById(R.id.viewColor1).performClick(); break;
                case  "#FDBE3B":  miscellaneouslayout.findViewById(R.id.viewColor2).performClick(); break;
                case  "#FF4842":  miscellaneouslayout.findViewById(R.id.viewColor3).performClick(); break;
                case  "#3A52Fc":  miscellaneouslayout.findViewById(R.id.viewColor4).performClick(); break;
                case  "#000000":  miscellaneouslayout.findViewById(R.id.viewColor5).performClick(); break;
            }
        }
// alreadyAvailableNote!= null : means that this Note already exists so this should be an update or just a view
        if(alreadyAvailableNote!=null){
            miscellaneouslayout.findViewById(R.id.layoutDeleteNote).setVisibility(View.VISIBLE);
            miscellaneouslayout.findViewById(R.id.layoutDeleteNote).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                        showDeleteNote();
                }
            });
        }
    }

    private void selectImage() {

        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        if (intent.resolveActivity(getPackageManager()) != null) { // this function suppose to return true, it doesn't seem to do, i'll make it ==
            Log.d("start the intent :", " right know");
            startActivityForResult(intent, REQUEST_CODE_SELECT_IMAGE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectImage();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SELECT_IMAGE && resultCode == RESULT_OK) {
            if (data != null) {
                Uri selectedImageUrl = data.getData();
                if (selectedImageUrl != null) {
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(selectedImageUrl);
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                        noteImage.setImageBitmap(bitmap);
                        noteImage.setVisibility(View.VISIBLE);
                        findViewById(R.id.removeImageBtn).setVisibility(View.VISIBLE);
                       selectedImagePath = getPathFromUri(selectedImageUrl);
                    } catch (Exception e) {
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }
        }
    }

   private String getPathFromUri(Uri contentUri){
        String filePath;
        Cursor cursor = getContentResolver()
                .query(contentUri, null,null,null,null);
        if(cursor==null){
            filePath = contentUri.getPath();
        }else{
            cursor.moveToFirst();
            int index = cursor.getColumnIndex("_data");
            filePath = cursor.getString(index);
            cursor.close();
        }
        return filePath;
    }

    private void showDeleteNote(){
        if(alertDialogDeleteNote==null){
            AlertDialog.Builder builder = new AlertDialog.Builder(createNoteActivity.this);
            View view = LayoutInflater.from(this).inflate(
                    R.layout.layout_delete_note,
            (ViewGroup) findViewById(R.id.layoutDeleteNoteContainer));
            builder.setView(view);
            alertDialogDeleteNote= builder.create();
        if(alertDialogDeleteNote.getWindow()!=null){
            alertDialogDeleteNote.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }
        view.findViewById(R.id.deleteBTN).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                class DeleteNoteTask extends AsyncTask<Void, Void, Void>{

                    @Override
                    protected Void doInBackground(Void... voids) {
                        NotesDatabase.getDatabase(getApplicationContext()).NoteDao().deleteNote(alreadyAvailableNote);
                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void unused) {
                        super.onPostExecute(unused);
                        Intent intent = new Intent();
                        intent.putExtra("isNoteDeleted", true);
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                }
                new DeleteNoteTask().execute();
            }
        });
        view.findViewById(R.id.cancelDeleteBTN).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             alertDialogDeleteNote.dismiss();
            }
        });
        }
        alertDialogDeleteNote.show();
    }

    private void showAddUrlDialog(){
        if(alertDialogAddUrl==null){
            AlertDialog.Builder builder = new AlertDialog.Builder(createNoteActivity.this);
            View view = LayoutInflater.from(this).inflate(
                    R.layout.add_url
                    ,(ViewGroup) findViewById(R.id.layoutAddUrlContainer));
            builder.setView(view);
            alertDialogAddUrl = builder.create();
            if(alertDialogAddUrl.getWindow()!= null){
                alertDialogAddUrl.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            }
            final EditText inputUrl = view.findViewById(R.id.inputURLID);
            inputUrl.requestFocus();
            view.findViewById(R.id.addUrlText).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(inputUrl.getText().toString().trim().isEmpty()){
                        Toast.makeText(createNoteActivity.this, "Enter Url", Toast.LENGTH_SHORT).show();
                    }else if(!Patterns.WEB_URL.matcher(inputUrl.getText().toString()).matches()){
                        Toast.makeText(createNoteActivity.this, "Enter Valid Url", Toast.LENGTH_SHORT).show();
                    }else{
                        textUrl.setText(inputUrl.getText().toString());
                        layout_url.setVisibility(View.VISIBLE);
                        alertDialogAddUrl.dismiss();
                    }
                }
            });
            view.findViewById(R.id.cancelText).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialogAddUrl.dismiss();
                    }
                });

        }
        alertDialogAddUrl.show();
    }

    private void saveNote() {
        if (inputTitle.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "title can't be empty", Toast.LENGTH_SHORT).show();
            return;
        } else if (inputSubtitle.getText().toString().trim().isEmpty()
                && inputNote.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Note can't be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        final Note note = new Note();
        note.setTitle(inputTitle.getText().toString());
        note.setSubtitle(inputSubtitle.getText().toString());
        note.setNoteText(inputNote.getText().toString());
        note.setDateTime(textDateTime.getText().toString());
        note.setColor(noteColorSelected);
        note.setImagePath(selectedImagePath);
        if(layout_url.getVisibility()==View.VISIBLE){
            note.setWebLink(textUrl.getText().toString());
        }

        if(alreadyAvailableNote != null){
            note.setId(alreadyAvailableNote.getId());
        }

        @SuppressLint("StaticFieldLeak")
        class saveNoteTask extends AsyncTask<Void, Void, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                NotesDatabase.getDatabase(getApplicationContext()).NoteDao().insertNote(note);
                return null;
            }

            @Override
            protected void onPostExecute(Void unused) {
                super.onPostExecute(unused);
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
            }
        }
        new saveNoteTask().execute();
    }

    private void saveImage() {
        ImageView savebutton = findViewById(R.id.saveButtonID);
        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveNote();
            }
        });
    }

    private void backImage() {
        ImageView imageBack = findViewById(R.id.imagebackimage);
        imageBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void initViews() {
        inputTitle = findViewById(R.id.inputNoteTitle);
        inputSubtitle = findViewById(R.id.inputNoteSubtitleID);
        inputNote = findViewById(R.id.inputNoteID);
        noteImage = findViewById(R.id.addNoteImage);
        selectedImagePath="";
        textDateTime = findViewById(R.id.textDateTimeID);
        textDateTime.setText(
                new SimpleDateFormat("EEEE, dd MMMM yyyy HH:mm a", Locale.getDefault())
                        .format(new Date())
        );
        subtitleIndicatorView = findViewById(R.id.subtitleIndicatorID);

        textUrl = findViewById(R.id.addTextWebUrl);
        layout_url = findViewById(R.id.layoutWebUrl);
    }

    private void setSubtitleIndicatorColor() {
        GradientDrawable gradientDrawable = (GradientDrawable) subtitleIndicatorView.getBackground();
        gradientDrawable.setColor(Color.parseColor(noteColorSelected));
    }
}