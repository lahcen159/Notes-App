package com.example.notes_app_tutorial.Adapters;

import android.annotation.SuppressLint;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.opengl.Visibility;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.notes_app_tutorial.Entities.Note;
import com.example.notes_app_tutorial.Listeners.NotesListener;
import com.example.notes_app_tutorial.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class noteAdapter extends RecyclerView.Adapter<noteAdapter.noteHolderAdapter>{

    private List<Note> notes;
    private NotesListener notesListener;
    private Timer timer;
    private List<Note> notesSource;

    public noteAdapter(List<Note> notes, NotesListener notesListener){
        this.notes=notes;
        this.notesListener = notesListener;
        notesSource = notes;
    }

    @NonNull
    @Override
    public noteHolderAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new noteHolderAdapter(LayoutInflater.from(parent.getContext())
        .inflate(R.layout.notecontainer, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull noteHolderAdapter holder, @SuppressLint("RecyclerView") final int position) {
        holder.setNote(notes.get(position));
        holder.noteLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                notesListener.onClickedListener(notes.get(position), position );
            }
        });
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    class noteHolderAdapter extends RecyclerView.ViewHolder{
        TextView titleText;
        TextView subtitleText;
        TextView textDate;
        ImageView noteImage;
        LinearLayout noteLayout;
        public noteHolderAdapter(@NonNull View view) {
            super(view);
            titleText = view.findViewById(R.id.textTitle);
            subtitleText = view.findViewById(R.id.textSubtitle);
            textDate = view.findViewById(R.id.textDateTime);
            noteLayout = view.findViewById(R.id.note_container);
            noteImage = view.findViewById(R.id.imageNote);
        }
        void setNote(Note note){
            titleText.setText(note.getTitle());
            if(note.getSubtitle().trim().isEmpty()){
                subtitleText.setVisibility(View.GONE);
            }else{
                subtitleText.setText(note.getSubtitle());
            }
            textDate.setText(note.getDateTime());
            GradientDrawable gradientDrawable = (GradientDrawable) noteLayout.getBackground();
            if(note.getColor()!=null){
            gradientDrawable.setColor(Color.parseColor(note.getColor()));
            }else{
                gradientDrawable.setColor(Color.parseColor("#333333"));
            }
            if(note.getImagePath()!=null){
                Log.d("note has a path", " we set it now");
                noteImage.setImageBitmap(BitmapFactory.decodeFile(note.getImagePath()));
                noteImage.setVisibility(View.VISIBLE);
            }else{
                Log.d("doesn't have a Path", "visibility is gone");
                noteImage.setVisibility(View.GONE);
            }
        }
    }
    public void searchNotes(final String searchKeyWord){
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if(searchKeyWord.trim().isEmpty()){
                    notes = notesSource;
                }else{
                    ArrayList<Note> temp = new ArrayList<>();
                    for(Note note : notesSource){
                        if(note.getTitle().toLowerCase().contains(searchKeyWord.toLowerCase())
                        || note.getSubtitle().toLowerCase().contains(searchKeyWord.toLowerCase())
                        || note.getNoteText().toLowerCase().contains(searchKeyWord.toLowerCase())){
                                temp.add(note);
                        }
                    } notes = temp;
                }
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        notifyDataSetChanged();
                    }
                });

            }
        }, 500);
    }
    public void cancelTimer(){
        if(timer != null){
            timer.cancel();
        }
    }
}
