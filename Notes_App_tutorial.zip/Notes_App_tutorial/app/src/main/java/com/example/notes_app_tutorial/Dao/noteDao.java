package com.example.notes_app_tutorial.Dao;


import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Dao;

import com.example.notes_app_tutorial.Entities.Note;

import java.util.List;

@Dao
public interface noteDao {

@Query("SELECT * FROM notes ORDER BY id DESC")
    List<Note> getAllNotes();
@Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertNote(Note note);

@Delete
    void deleteNote(Note note);
}
