package com.example.notes_app_tutorial.Listeners;

import com.example.notes_app_tutorial.Entities.Note;

public interface NotesListener {
    void onClickedListener(Note note, int position);
}
